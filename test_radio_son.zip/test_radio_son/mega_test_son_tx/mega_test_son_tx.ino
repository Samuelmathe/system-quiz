/*
 * TEST — Mega → Nano son (radio nRF24 uniquement)
 * Envoie en boucle les commandes 200 (buzz équipe 1), 201 (victoire), 202 (échec),
 * même format SonPayload que mega30Equipe.ino / nano_son_final.ino
 *
 * Câblage RF24 Mega : CE=9, CSN=53 (identique au projet principal)
 * Moniteur série USB Mega : 9600 baud pour voir les logs TX
 */
#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>

RF24 radio(9, 53);

const byte adresseSon[6] = "00002";
#define RADIO_CHANNEL 108
#define LED_PIN 13

struct SonPayload {
    uint16_t cmd;
    uint8_t team;
    uint8_t reserved;
};

void envoyerSonPayload(uint16_t cmd, uint8_t team) {
    SonPayload p = {cmd, team, 0};
    radio.stopListening();
    radio.openWritingPipe(adresseSon);
    radio.setAutoAck(false);
    bool ok = radio.write(&p, sizeof(p));
    radio.setAutoAck(true);
    radio.startListening();
    Serial.print(ok ? F("TX OK  ") : F("TX FAIL "));
    Serial.print(F("cmd="));
    Serial.print(cmd);
    Serial.print(F(" team="));
    Serial.println(team);
}

void setup() {
    Serial.begin(9600);
    pinMode(LED_PIN, OUTPUT);

    if (!radio.begin()) {
        Serial.println(F("ERREUR: module nRF24L01+ non detecte."));
        while (true) {
            digitalWrite(LED_PIN, HIGH);
            delay(200);
            digitalWrite(LED_PIN, LOW);
            delay(200);
        }
    }

    radio.setChannel(RADIO_CHANNEL);
    radio.setAddressWidth(5);
    radio.setPALevel(RF24_PA_MAX);
    radio.setDataRate(RF24_250KBPS);
    radio.setCRCLength(RF24_CRC_16);
    radio.setPayloadSize(sizeof(SonPayload));
    radio.setRetries(5, 15);
    radio.setAutoAck(false);
    radio.openWritingPipe(adresseSon);
    radio.stopListening();

    Serial.println(F("=== Mega TEST envoi son (adresse 00002, canal 108) ==="));
    Serial.println(F("Cycle toutes les 4 s : 200(team=1) -> 201 -> 202"));
}

unsigned long lastSend = 0;
uint8_t etape = 0;

void loop() {
    unsigned long now = millis();
    if (now - lastSend < 4000UL) {
        return;
    }
    lastSend = now;

    digitalWrite(LED_PIN, HIGH);

    if (etape == 0) {
        Serial.println(F("--- 200 BUZZ equipe 1 ---"));
        envoyerSonPayload(200, 1);
        etape = 1;
    } else if (etape == 1) {
        Serial.println(F("--- 201 VICTOIRE ---"));
        envoyerSonPayload(201, 0);
        etape = 2;
    } else {
        Serial.println(F("--- 202 ECHEC ---"));
        envoyerSonPayload(202, 0);
        etape = 0;
    }

    digitalWrite(LED_PIN, LOW);
}
