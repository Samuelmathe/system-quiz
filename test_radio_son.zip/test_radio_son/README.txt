Test radio Mega <-> Nano son (commandes 200 / 201 / 202)
=====================================================

1) mega_test_son_tx
   - Ouvrir dans Arduino IDE le dossier mega_test_son_tx / mega_test_son_tx.ino
   - Carte : Arduino Mega 2560
   - Téléverser. Ouvrir le moniteur série 9600 baud : vous devez voir TX OK / FAIL et le cycle 200 -> 201 -> 202.

2) nano_test_son_rx
   - Ouvrir nano_test_son_rx / nano_test_son_rx.ino
   - Carte : Arduino Nano
   - Moniteur série 115200 baud : à chaque paquet reçu, une ligne "RECU cmd=..."

Conditions identiques au projet principal :
- Adresse pipe son : "00002" (5 octets + '\0' dans le tableau)
- Canal RF : 108
- Débit : 250 kbps, CRC 16 bits
- Paquet : SonPayload = uint16_t cmd + uint8_t team + uint8_t reserved (4 octets)
- Mega : CE=9, CSN=53  |  Nano : CE=9, CSN=10

Pour tester avec le vrai nano DFPlayer : téléverser plutôt nano_son_final.ino ;
les MP3 0001 / 0002 / 0003 (et 0101 pour buzz équipe 1) doivent être sur la carte SD.
