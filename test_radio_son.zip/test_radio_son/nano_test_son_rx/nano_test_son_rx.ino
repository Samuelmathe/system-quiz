/*
 * TEST — Nano récepteur (même pipe que nano_son_final.ino)
 * Affiche sur le moniteur série USB les paquets SonPayload reçus (200 / 201 / 202).
 * Pas de DFPlayer : uniquement pour valider la liaison radio Mega → Nano.
 *
 * Câblage RF24 Nano : CE=9, CSN=10 (identique nano_son_final.ino)
 * Moniteur série : 115200 baud
 */
#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>

RF24 radio(9, 10);

const byte adresseSon[6] = "00002";
#define RADIO_CHANNEL 108

struct SonPayload {
    uint16_t cmd;
    uint8_t team;
    uint8_t reserved;
};

void setup() {
    Serial.begin(115200);
    pinMode(LED_BUILTIN, OUTPUT);

    if (!radio.begin()) {
        Serial.println(F("ERREUR: nRF24 non detecte"));
        while (true) {
            digitalWrite(LED_BUILTIN, HIGH);
            delay(300);
            digitalWrite(LED_BUILTIN, LOW);
            delay(300);
        }
    }

    radio.setChannel(RADIO_CHANNEL);
    radio.setAddressWidth(5);
    radio.setPALevel(RF24_PA_MAX);
    radio.setDataRate(RF24_250KBPS);
    radio.setCRCLength(RF24_CRC_16);
    radio.setPayloadSize(sizeof(SonPayload));
    radio.setAutoAck(false);
    radio.openReadingPipe(1, adresseSon);
    radio.startListening();

    Serial.println(F("=== Nano TEST reception son (pipe 00002, canal 108) ==="));
    Serial.println(F("En attente de paquets SonPayload..."));

    for (int i = 0; i < 3; i++) {
        digitalWrite(LED_BUILTIN, HIGH);
        delay(80);
        digitalWrite(LED_BUILTIN, LOW);
        delay(80);
    }
}

void loop() {
    if (!radio.available()) {
        return;
    }

    SonPayload p = {0, 0, 0};
    radio.read(&p, sizeof(p));

    digitalWrite(LED_BUILTIN, HIGH);
    delay(40);
    digitalWrite(LED_BUILTIN, LOW);

    Serial.print(F("RECU cmd="));
    Serial.print(p.cmd);
    Serial.print(F(" team="));
    Serial.print(p.team);
    Serial.print(F("  -> "));
    if (p.cmd == 200) {
        Serial.println(F("BUZZ"));
    } else if (p.cmd == 201) {
        Serial.println(F("VICTOIRE"));
    } else if (p.cmd == 202) {
        Serial.println(F("ECHEC"));
    } else {
        Serial.println(F("(autre)"));
    }
}
